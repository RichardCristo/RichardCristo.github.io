USE examen;

select nombre, area, perimetro from barrios where nro_comuna = 3; -- 1
select nombre, area, perimetro from barrios where nro_comuna between 4 and 10; -- 2
select perimetro, area from barrios where id = 5; -- 3
select nro_comuna from barrios where nombre like 'v%'; -- 4
select nro_comuna from barrios where nombre like '&a%'; -- 5
select perimetro from barrios where(select id_caso from casos where id_caso = 15); -- 6
select area from barrios where(select id_caso from casos where id_caso = 7); -- 7
select id, nombre, nro_comuna from barrios where (select numero_de_caso from casos where numero_de_caso between 6000000 and 7000000); -- 8
select edad, genero from casos where(select id from barrios where id = 3); -- 9
select nombre, id from barrios where(select tipo_de_contagio from casos where tipo_de_contagio = "En Investigacion"); -- 10
select nombre, id from barrios where(select tipo_de_contagio from casos where edad < 18); -- 11
select id_caso, numero_de_caso, genero, edad from casos where(select id from barrios where id < 4); -- 12
select id_caso, numero_de_caso, genero, edad from casos where(select id from barrios where id != 13); -- 13

